// Package vobiz provides Vobiz WebSocket protocol serializer.
// Vobiz uses Twilio-compatible input (start/media/stop) but expects
// playAudio/clearAudio output format.
package vobiz

import (
	"encoding/base64"
	"encoding/json"

	"github.com/Voxray-AI/Voxray/pkg/audio"
	"github.com/Voxray-AI/Voxray/pkg/frames"
	"github.com/Voxray-AI/Voxray/pkg/frames/serialize"
)

// Serializer implements serialize.Serializer for Vobiz.
type Serializer struct {
	StreamSid  string
	CallSid    string
	SampleRate int
	VobizRate  int
}

// Params configures the Vobiz serializer.
type Params struct {
	VobizSampleRate int
	SampleRate      int
}

// NewSerializer returns a Vobiz serializer.
func NewSerializer(streamSid, callSid string, params *Params) *Serializer {
	s := &Serializer{
		StreamSid: streamSid,
		CallSid:   callSid,
		VobizRate: 8000,
	}
	if params != nil {
		if params.VobizSampleRate > 0 {
			s.VobizRate = params.VobizSampleRate
		}
		s.SampleRate = params.SampleRate
	}
	return s
}

// Setup implements serialize.SerializerWithSetup.
func (s *Serializer) Setup(start *frames.StartFrame) {
	if start != nil && s.SampleRate == 0 {
		s.SampleRate = start.AudioInSampleRate
	}
	if s.SampleRate == 0 {
		s.SampleRate = 16000
	}
}

// Serialize implements serialize.Serializer.
func (s *Serializer) Serialize(f frames.Frame) ([]byte, error) {
	data, _, err := s.serialize(f)
	return data, err
}

func (s *Serializer) serialize(f frames.Frame) ([]byte, bool, error) {
	switch v := f.(type) {
	case *frames.InterruptionFrame:
		// Vobiz expects clearAudio to stop playback
		out := map[string]string{"event": "clearAudio", "streamSid": s.StreamSid}
		b, err := json.Marshal(out)
		return b, false, err
	case *frames.AudioRawFrame:
		return s.serializeAudio(v.Audio, v.SampleRate)
	case *frames.TTSAudioRawFrame:
		return s.serializeAudio(v.Audio, v.SampleRate)
	case *frames.OutputAudioRawFrame:
		return s.serializeAudio(v.Audio, v.SampleRate)
	case *frames.TransportMessageFrame:
		return nil, false, nil
	}
	return nil, false, nil
}

func (s *Serializer) serializeAudio(pcm []byte, inRate int) ([]byte, bool, error) {
	var resampled []byte
	if inRate != s.VobizRate {
		resampled = audio.Resample16MonoAlloc(pcm, inRate, s.VobizRate)
	} else {
		resampled = pcm
	}
	ulawBytes := audio.EncodeULaw(resampled)
	if len(ulawBytes) == 0 {
		return nil, false, nil
	}
	payload := base64.StdEncoding.EncodeToString(ulawBytes)
	// Vobiz expects: {event: "playAudio", media: {contentType, sampleRate, payload}}
	out := map[string]interface{}{
		"event": "playAudio",
		"media": map[string]interface{}{
			"contentType": "audio/x-mulaw",
			"sampleRate":  8000,
			"payload":     payload,
		},
	}
	b, err := json.Marshal(out)
	return b, false, err
}

// Deserialize implements serialize.Serializer.
// Vobiz input is Twilio-compatible: start, media, stop events.
func (s *Serializer) Deserialize(data []byte) (frames.Frame, error) {
	var msg struct {
		Event string `json:"event"`
		Start struct {
			StreamSid string `json:"streamSid"`
			CallSid   string `json:"callSid"`
		} `json:"start"`
		Media struct {
			Payload string `json:"payload"`
		} `json:"media"`
	}
	if err := json.Unmarshal(data, &msg); err != nil {
		return nil, err
	}
	switch msg.Event {
	case "start":
		if msg.Start.StreamSid != "" {
			s.StreamSid = msg.Start.StreamSid
		}
		if msg.Start.CallSid != "" {
			s.CallSid = msg.Start.CallSid
		}
		return nil, nil
	case "media":
		if msg.Media.Payload == "" {
			return nil, nil
		}
		ulawBytes, err := base64.StdEncoding.DecodeString(msg.Media.Payload)
		if err != nil || len(ulawBytes) == 0 {
			return nil, nil
		}
		pcm := audio.DecodeULaw(ulawBytes)
		if len(pcm) == 0 {
			return nil, nil
		}
		sr := s.SampleRate
		if sr == 0 {
			sr = 16000
		}
		if s.VobizRate != sr {
			pcm = audio.Resample16MonoAlloc(pcm, s.VobizRate, sr)
		}
		return frames.NewAudioRawFrame(pcm, sr, 1, 0), nil
	case "stop":
		return &frames.EndFrame{}, nil
	}
	return nil, nil
}

// Ensure Serializer implements the interfaces.
var (
	_ serialize.Serializer          = (*Serializer)(nil)
	_ serialize.SerializerWithSetup = (*Serializer)(nil)
)
